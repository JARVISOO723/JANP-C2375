package com.anudip.lab.dao;

public interface LibraryDAO {
	
	public void addBook();
	
	public void getBook();
	
	public void updateBook();
	
	public void deleteBook();

}